public class MySlotMachine_Tester {
   public static void main(String [] args) {
      MySlotMachine12 game = new MySlotMachine12();
      game.startGame();
   }
}         