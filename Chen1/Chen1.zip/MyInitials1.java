// *******************************************************

// Purpose: Getting Started with Java and JGRASP. Creating, saving, 
//			   compiling, debugging, and running a Java program.	
//	Input:	None
//	Output:	Displaying a short paragraph about myself and 
//			   initials in large block letters.
//	Author:  Jenny Chen
//	Date:	   1/11/2017
//	Class:   CS1301B
//	Program:	#1(MyInitia1s1.java)

//***********************************************************

//Gave my class a name (Blueprint) 
public class MyInitials1 {

// Main method 
   public static void main (String [] args) {
   
// Prints out a paragraph about myself and the block letters of my initials.
// The ln after prints where you want your messages to be.    
// Take out ln after print to get rid of spaces.
	System.out.print("I am from Gainesville, Georgia. I am Chinese and Taiwanese mixed.");
    
   System.out.print("I chose VSU because I had a family member that attended here and recommended VSU to me.");
   
   System.out.print("I am a math major because I am intrested in it, and I like problem solving.");
   
 // "\n"The = space b/w paragraph and block letters  
   System.out.println("\n");
   
//********************************************************************

 //My Initials in block letters (I don't have a middle name)
   
   System.out.println("    JJJJJJJJJJJJJJJJJJJJJ            CCCCCCCCCCCCCCCCCCC");
   System.out.println("    JJJJJJJJJJJJJJJJJJJJJ            CCCCCCCCCCCCCCCCCCC");
   System.out.println("          JJJJJJJJ                   CCCCCCC"            );
   System.out.println("          JJJJJJJJ                   CCCCCCC"            );
   System.out.println("          JJJJJJJJ                   CCCCCCC"            );   
   System.out.println("          JJJJJJJJ                   CCCCCCC"            );
   System.out.println("          JJJJJJJJ                   CCCCCCC"            );
   System.out.println("          JJJJJJJJ                   CCCCCCC"            );
   System.out.println("          JJJJJJJJ                   CCCCCCC"            );
   System.out.println("          JJJJJJJJ                   CCCCCCC"            ); 
   System.out.println("    JJJJJJJJJJJJJJ                   CCCCCCCCCCCCCCCCCCC"); 
   System.out.println("    JJJJJJJJJJJJJJ                   CCCCCCCCCCCCCCCCCCC");
   
   
   
   
   //end main
   }  

   //end class
    } 
   
//**********************************************************************
